# Graph — schema, loading, algorithms, case memory

Owner: P1. This is the short schema doc + reload-from-scratch instructions
required by the Day-1 Definition of Done.

## Known validation gap (read this first)

Everything in this folder was written **without a live TigerGraph compiler
available**: local Docker CE needs a free license (self-serve at
https://dl.tigergraph.com, ~2 minutes) and TigerGraph Savanna needs a signup
(https://savanna.tgcloud.io) — both are pending. GSQL syntax below follows
documented TigerGraph 4.x patterns as closely as possible, but the first
thing to do once either instance is live is run every file in order below
and fix whatever the real parser rejects. Do not assume it's bug-free until
that pass happens.

The Python MCP layer (`/mcp/tools.py`) works today in `fixture` mode
(`MCP_MODE=fixture`, the default) — it returns contract-shaped example data
with no graph connection, so P2 is not blocked by this gap.

## Data model

**Vertices:** `Customer`, `Card`, `Transaction`, `DeviceProfile`,
`EmailDomain`, `BillingRegion`, `ClosedCase` (immutable historical memory,
5,565 rows from `closed_cases_history.csv`), `InvestigationCase` (cases our
agent creates/updates — separate from `ClosedCase`), `Evidence`,
`PolicyClause`, `FraudTypology`, `Action`.

**Key design calls** (see comments in `01_schema.gsql` for full rationale):
- V1-V339 (Vesta's unnamed engineered features) are **not** loaded into the
  graph — they stay in `data/raw/transactions.csv` for any offline feature
  work. 300+ meaningless-by-name attributes on every Transaction vertex
  would be pure bloat.
- Only the "readable" `identity.csv` columns are exploded onto
  `Transaction` (id_01-11 ratings, id_15/23/30/31/33/34, DeviceType,
  DeviceInfo). The other ~21 uninterpreted id_* columns stay in the raw CSV.
- `DeviceProfile` is keyed on `DeviceInfo|OS|browser|screen`, exactly the
  fraud-ring backbone the dataset README specifies.
- `transactions.csv` has no `card_id` column — see "card_id derivation"
  below, this was the single hardest data-modeling problem in this dataset.
- `SHARES_EMAIL`/`SHARES_ADDRESS` (but not `SHARES_DEVICE`) are built with a
  `max_cards` threshold to avoid connecting half the customer base through
  generic email providers or populous billing regions. See
  `03_derived_edges.gsql` header.

## card_id derivation (read before touching transactions.csv)

`transactions.csv` gives `customer_id` + raw `card1..card6` issuer-code
fragments, **not** a `card_id` string. `case_pack.csv` and
`closed_cases_history.csv` DO give explicit `card_id` values like
`C08623-K2`. Empirically (verified against ~2,500 ground-truth-labeled
transactions before writing the ETL), the K-number in `card_id` is **not** a
clean deterministic function of the `card1..card6` tuple — a lexical-sort
heuristic only gets ~91% right.

The ETL (`loading/prepare_data.py`) therefore:
1. Takes `card_id` directly from `case_pack.csv` / `closed_cases_history.csv`
   for every transaction those files actually reference (100% correct for
   everything that's graded or retrieved as case memory — confirmed 0
   missing referenced transaction IDs after the run).
2. Best-effort clusters the remaining ~87% of transactions per customer,
   folding near-blank card-detail rows (a data-sparsity artifact, not a
   second card) into the dominant tuple, and lexically ranking any genuinely
   distinct remaining tuples.

This is a documented approximation, not a bug — see the docstring at the
top of `prepare_data.py` for the full investigation.

## Reload from scratch

```bash
# 1. Start TigerGraph (local Docker CE example; adjust for Savanna)
docker run -d -p 14022:22 -p 9000:9000 -p 14240:14240 --name tigergraph \
  --ulimit nofile=1000000:1000000 -v tigergraph_data:/home/tigergraph/mydata \
  -t tigergraph/tigergraph:latest
# apply your free CE license: docker exec -u tigergraph tigergraph gadmin license set <KEY>

# 2. Run the ETL (raw CSVs -> data/processed/*.csv)
python graph/loading/prepare_data.py

# 3. Load schema
gsql graph/schema/01_schema.gsql

# 4. Load data (adjust file paths/host as needed; run from inside the
#    container or via gsql -u <user> -p <pass> --ip <host> with file paths
#    the GSQL server can see, e.g. docker cp the processed/ folder in first)
gsql -g FraudGraph graph/loading/02_loading_jobs.gsql
gsql -g FraudGraph 'RUN LOADING JOB load_customers USING customers_file="data/processed/customers.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_cards USING cards_file="data/processed/cards.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_device_profiles USING devices_file="data/processed/device_profiles.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_email_domains USING emails_file="data/processed/email_domains.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_billing_regions USING regions_file="data/processed/billing_regions.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_transactions USING txns_file="data/processed/transactions_clean.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_closed_cases USING closed_cases_file="data/raw/closed_cases_history.csv"'
gsql -g FraudGraph 'RUN LOADING JOB load_policy_typology_action USING policy_file="graph/loading/policy_clauses.tsv", typology_file="graph/loading/fraud_typologies.tsv", action_file="graph/loading/actions.tsv"'

# 5. Build derived fraud-ring edges
gsql -g FraudGraph graph/algorithms/03_derived_edges.gsql
gsql -g FraudGraph "RUN QUERY build_shares_device()"
gsql -g FraudGraph "RUN QUERY build_shares_email(30)"
gsql -g FraudGraph "RUN QUERY build_shares_address(60)"

# 6. Install investigation queries + write-back job
gsql -g FraudGraph graph/algorithms/04_graph_queries.gsql
gsql -g FraudGraph graph/case_memory/05_case_writeback.gsql

# 7. Point the MCP tools at this instance
export MCP_MODE=live
export TG_HOST=http://localhost   # or your Savanna workspace URL
```

## Files

| File | Purpose |
|---|---|
| `schema/01_schema.gsql` | Vertex/edge/graph definitions |
| `loading/prepare_data.py` | ETL: raw CSVs -> clean, load-ready CSVs |
| `loading/02_loading_jobs.gsql` | GSQL LOADING JOB definitions |
| `loading/policy_clauses.tsv`, `fraud_typologies.tsv`, `actions.tsv` | Reference data transcribed from the dataset README's Fraud Policy section |
| `algorithms/03_derived_edges.gsql` | SHARES_DEVICE/EMAIL/ADDRESS self-join builders |
| `algorithms/04_graph_queries.gsql` | find_fraud_ring, get_transaction_velocity, shortest_path_between_cards, get_account_subgraph, get_policy_context, get_prior_similar_cases |
| `case_memory/05_case_writeback.gsql` | write_case_to_graph — the case-memory write path |
| `/mcp/tools.py` | Python layer P2 calls; fixture mode works today, live mode pending validation |
| `/contracts/mcp_tool_contracts.json` | The published I/O contract |
